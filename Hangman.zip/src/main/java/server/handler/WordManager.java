package server.handler;

import java.io.*;
import java.util.*;

public class WordManager {
    private List<String> words = new ArrayList<>();

    public WordManager() {
        loadWordsFromFile();
    }

    private void loadWordsFromFile() {
        try (BufferedReader br = new BufferedReader(new FileReader("words.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                words.add(line.trim());
            }
        } catch (IOException e) {
            System.err.println("Error reading words from file: " + e.getMessage());
        }
    }

    public List<String> getWords() {
        return words;
    }
} 